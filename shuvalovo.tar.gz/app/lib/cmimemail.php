<?

class CMimeMail {

    private $parts;
    private $to;
    private $from;
    private $headers;
    private $subject;

    public function __construct($to = "", $from = "", $subject = "", $body = "", $headers = "") {
        $this->parts = array();
        $this->to = $to;
        $this->from = $from;
        $this->subject = $subject;
        $this->headers = $headers;
        $this->setBody($body);
    }

    public function setTo($to) {
        $this->to = $to;
    }

    public function setFrom($from) {
        $this->from = $from;
    }

    public function setSubject($subject) {
        $this->subject = $subject;
    }

    public function setBody($body) {
        if (!empty($body))
            $this->addAttachment($body, "", "text/html; charset=windows-1251");
    }

    public function setHeaders($headers) {
        $this->headers = $headers;
    }

    // как раз сама функция добавления файлов в мыло
    public function addAttachment($message, $name = "", $ctype = "application/octet-stream", $encode = "") {
        $this->parts[] = array(
            "ctype" => $ctype,
            "message" => $message,
            "encode" => $encode,
            "name" => $name
        );
    }

    // Посылка сообщения
    public function send() {
        $mime = "";
        if (!empty($this->from))
            $mime .= "From: ".$this->from."\n";
        if (!empty($this->headers))
            $mime .= $this->headers."\n";
        $mime .= "MIME-Version: 1.0\n".$this->buildMultipart();
        return mail($this->to, $this->subject, "", $mime, '-fnoreply@3259404.ru');
    }

    // Построение сообщения (multipart)
    private function buildMessage($part) {
        $message = $part["message"];
        $message = chunk_split(base64_encode($message));
        $encoding = "base64";
        return "Content-Type: ".$part["ctype"].($part["name"] ? "; name = \"".$part["name"]."\"" : "")."\nContent-Transfer-Encoding: $encoding\n\n$message\n";
    }

    private function buildMultipart() {
        $boundary = "b".md5(uniqid(time()));
        $multipart = "Content-Type: multipart/mixed; boundary = $boundary\n\nThis  is a MIME encoded message.\n\n--$boundary";

        foreach ($this->parts as $part)
            $multipart .= "\n".$this->buildMessage($part)."--$boundary";

        $multipart .= "--\n";

        return $multipart;
    }

}

?>