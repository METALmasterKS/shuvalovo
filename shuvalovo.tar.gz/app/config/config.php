<?php
// Config

// define(NAME, 'value')
