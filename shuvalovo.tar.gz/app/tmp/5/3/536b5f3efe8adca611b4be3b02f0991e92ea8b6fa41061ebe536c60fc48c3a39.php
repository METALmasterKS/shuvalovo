<?php

/* b4.html */
class __TwigTemplate_536b5f3efe8adca611b4be3b02f0991e92ea8b6fa41061ebe536c60fc48c3a39 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html", "b4.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "   
   <script type=\"text/javascript\" src=\"../jquery.js\"></script>
<script type=\"text/javascript\" src=\"../cboxmod.js\"></script>
<table class=\"contentTab\" style=\"width:750px\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
\t<tr> 
\t\t<td class=\"contentTabTd1\"></td> 
\t\t<td class=\"contentTabTd2\"></td>
\t</tr>
\t<tr> 
\t\t<td class=\"contentTabTd3\">
\t\t\t<div class=\"buildinfo\" id=\"liter_b\">
\t\t\t\t<div class=\"flatinfo\">
\t\t\t\t\t<p><b>Квартира №4</b> <span class=\"reserved\">(забронирована)</span></p>
\t\t\t\t\t<table class=\"sqrinfo\">
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>Общая площадь:</td> 
\t\t\t\t\t\t\t<td><strong>245,6 м<sup>2</sup></strong></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>Площадь квартиры 
\t\t\t\t\t\t\t<br>без технических помещений:</td> 
\t\t\t\t\t\t\t<td><strong>175,1 м<sup>2</sup></strong></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>Площадь цокольного этажа:</td> 
\t\t\t\t\t\t\t<td><strong>80,8 м<sup>2</sup></strong></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>Количество уровней:</td> 
\t\t\t\t\t\t\t<td><strong>3</strong></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</table>
\t\t\t\t\t<p>Вид из окон:
\t\t\t\t\t<br>&ndash; с 1-го этажа: на улицу Первомайская
\t\t\t\t\t<br>&ndash; со 2-го этажа: во двор и на улицу Первомайская
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t\t<div class=\"otherlinks\">
\t\t\t\t\t<p>Другие квартиры в этом доме:</p>
\t\t\t\t\t<p><a href=\"/html/b5.html\" title=\"Четырёхуровневая квартира с мансардным этажом общей площадью 316,7 м&sup2;\">квартира №5</a></p>
\t\t\t\t\t<p><a href=\"/html/b6.html\" title=\"Четырёхуровневая квартира с мансардным этажом общей площадью 419,5 м&sup2;\">квартира №6</a></p>
\t\t\t\t</div>
\t\t\t\t<p style=\"text-indent:0\"><a href=\"/html/liter-b.html\" title=\"Трёхквартирный дом, литер Б (ул. Первомайская, д.26 лит А)\" class=\"backlink\">Назад к описанию дома</a></p>
\t\t\t</div>
\t\t\t<div class=\"flatplans\">
\t\t\t\t<div class=\"shem1TabTd5 floorplan\">
\t\t\t\t\t<a href=\"?4b_2\" title=\"Подробнее\">Второй этаж<br>
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"254\" height=\"151\" class=\"shem13\" alt=\"2 этаж\"></a>
\t\t\t\t</div>
\t\t\t\t<div class=\"shem1TabTd4 floorplan\">
\t\t\t\t\t<a href=\"?4b_1\" title=\"Подробнее\">Первый этаж<br>
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"254\" height=\"151\" class=\"shem12\" alt=\"1 этаж\"></a>
\t\t\t\t</div>
\t\t\t\t<div class=\"shem1TabTd3 floorplan\">
\t\t\t\t\t<a href=\"?4b_0\" title=\"Подробнее\">Цокольный этаж<br>
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"254\" height=\"151\" class=\"shem11\" alt=\"Цокольный этаж\"></a>
\t\t\t\t</div> 
\t\t\t</div>
\t\t</td> 
\t\t<td class=\"contentTabTd4\"></td>
\t</tr>
\t<tr> 
\t\t<td class=\"contentTabTd5\"></td> 
\t\t<td class=\"contentTabTd6\"></td>
\t</tr>
</table>
   
  ";
    }

    public function getTemplateName()
    {
        return "b4.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 4,  28 => 3,  11 => 1,);
    }
}
