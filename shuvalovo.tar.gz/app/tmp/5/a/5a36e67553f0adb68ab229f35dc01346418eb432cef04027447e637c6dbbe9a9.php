<?php

/* desc.html */
class __TwigTemplate_5a36e67553f0adb68ab229f35dc01346418eb432cef04027447e637c6dbbe9a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html", "desc.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        // line 5
        echo "<table class=\"contentTab\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:510px\">
 <tr>
  <td class=\"contentTabTd1\"></td>
  <td class=\"contentTabTd2\"><img src=\"/pic/pixel.gif\" width=\"6\" height=\"6\" alt=\"\"></td>
 </tr>
 <tr>
  <td class=\"contentTabTd3\" style=\"padding:10px 40px 10px 60px\">
  <br>
   <p>
    «Усадьба у озера» располагается в красивейшем районе Санкт-Петербурга – Шувалово-Озерки, на восточном берегу
    Нижнего Большого Суздальского Озера. Район сочетает прелести загородной жизни и развитую инфраструктуру города.
    Единство архитектурного стиля «Усадьбы у озера» прекрасно гармонирует с неповторимым видом из окон на парк и озеро.</p>
    <p>Коттеджи находятся в историческом месте, где когда-то были построены, а позже снесены уникальные дачные строения.
    Архитектурные решения фасадов воссозданы по историческим аналогам: в декоративной отделке использован кирпич
    бежевого цвета в сочетании с натуральным известняком.<br>
    <p>Коттеджи обеспечены всеми коммуникациями: системой центрального водоснабжения, газоснабжением,
    электроснабжением, канализацией. Отопление и горячее водоснабжение производится от поквартирных термоблоков.</p>
    <p>Все коттеджи двухэтажные с мансардным этажом и цокольным этажом, имеют отдельные входы с участка.</p>
    <br>
    <p><b>На ВСЕ коттеджи получены свидетельства о собственности.</b></p>
  </td>
  <td class=\"contentTabTd4\"></td>
 </tr>
 <tr>
  <td class=\"contentTabTd5\"><img src=\"/pic/pixel.gif\" width=\"6\" height=\"6\" alt=\"\"></td>
  <td class=\"contentTabTd6\"></td>
 </tr>
</table>
   
";
    }

    public function getTemplateName()
    {
        return "desc.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 5,  28 => 4,  11 => 1,);
    }
}
