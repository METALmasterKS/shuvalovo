<?php

/* index.html */
class __TwigTemplate_3afb99cf8071a4c5f82a261d3f356c63602ac9325afeadb25f2edfbc8117ee26 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html", "index.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        // line 5
        echo "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"width:600px;\">
    <tr>
        <td class=\"contentTabTd1\"></td>
        <td class=\"contentTabTd2\"></td>
    </tr>
    <tr>
        <td class=\"contentTabTd3\" style=\"padding:25px 50px 0 100px; font-size: 14px;\">
            <p>
                Как приятно после суеты большого города вернуться домой и окунуться в тишину и гармонию коттеджного поселка
                Петербурга. То, что «Усадьба у озера» относится к элитной недвижимости Петербурга, не возникает сомнений.
                Таунхаусы обеспечены всеми коммуникациями, располагаются в уникальном месте, на берегу Суздальского озера,
                где в 18-19 веках находились дачные строения рода Шуваловых.</p>
            <p>Продажа элитной недвижимости, как и покупка элитной квартиры Петербурга – дело, требующее особого подхода.
                Продажа коттеджей в Петербурге в настоящее время очень актуальна. Все больше людей выбирают комфортную и уютную
                жизнь вдали от суматохи большого города.</p>
            <p>«Усадьба у озера» отличается от других таунхаусов Петербурга тем, что <span style=\"white-space:nowrap\">это не просто загородный дом,</span>
                это определенный стиль жизни. Единое стилистическое и архитектурное решение фасадов, воссозданных по историческим
                аналогам, прекрасно сочетается с великолепием окружающей природы. Открывающийся из окон вид на парк и озеро
                принесут в дом гармонию и спокойствие.</p>
            <!--  
            <div align=left>
            <FONT SIZE=\"+2\" COLOR=\"#660033\"> <strong>ВНИМАНИЕ!<br>
            <nobr> Весеннее предложение!  </nobr></strong></FONT>
            <br>
            <FONT SIZE=\"+2\" COLOR=\"#660033\"><strong><nobr>58 500 руб. за кв. метр!</nobr></strong></FONT>
            </div>
            -->
            <br>
            <p style=\"text-align:right\"><strong>На ВСЕ квартиры получены свидетельства о собственности.<br>Электричество, газ, водопровод и канализация подключены.</strong></p>
            <p style=\"text-align:right\"><strong>Рассматривается зачет имеющейся недвижимости.<br />
                    Возможна ипотека с участием банков ВТБ-24 или UniCredit.</strong></p>
            <br />
        </td>
        <td class=\"contentTabTd4\"></td>
    </tr>
    <tr>
        <td class=\"contentTabTd5\"></td>
        <td class=\"contentTabTd6\"></td>
    </tr>
</table>
";
    }

    public function getTemplateName()
    {
        return "index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 5,  28 => 4,  11 => 1,);
    }
}
