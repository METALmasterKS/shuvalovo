<?php

/* structura.html */
class __TwigTemplate_36118322cb976511ff472af48ebf66a0a31acd63b457757cd5cee81d593bec43 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html", "structura.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "
    <table class=\"contentTab2\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
        <tr>
            <td style=\"width:490px;line-height:0\"><img src=\"/pic/pixel.gif\" width=\"490\" height=\"1\" border=\"0\" alt=\"\" /></td>
            <td class=\"contentTab2Td2\"><img src=\"/pic/pixel.gif\" width=\"6\" height=\"6\" border=\"0\" alt=\"\" /></td>
            <td class=\"contentTab2Td1\"></td>
            <td class=\"contentTab2Td1\"></td>
        </tr>
        <tr>
            <td></td>
            <td class=\"contentTab2Td4\"></td>
            <td class=\"contentTab2Td3\" style=\"padding-left:10px\">
                <span style=\"padding:10px; display:block;\">
                    <table class=\"placeTab\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
                        <tr>
                            <td class=\"placeTabTd1\">
                                <span style=\"color:#909191; font-size:10px;\">
                                    <br><b>Расположение:&nbsp;&nbsp;&nbsp;&nbsp;</b><br><br>
                                    Для увеличения<br>нажмите на<br>изображениее
                                </span>
                            </td>
                            <td class=\"placeTabTd2\">
                                <a href=\"javascript:void(0)\" onClick=\"openImage('karta_02', '&lt;&#1064;&#1091;&#1074;&#1072;&#1083;&#1086;&#1074;&#1089;&#1082;&#1072;&#1103; &#1091;&#1089;&#1072;&#1076;&#1100;&#1073;&#1072;&gt;')\">
                                    <img src=\"/pic/pixel.gif\" class=\"place1\" width=\"172\" height=\"152\" border=\"0\" alt=\"Карта, нажмите для увеличения\" />
                                </a>
                            </td>
                            <td class=\"placeTabTd3\">
                                <a href=\"javascript:void(0)\" onClick=\"openImage('karta_01', '&lt;&#1064;&#1091;&#1074;&#1072;&#1083;&#1086;&#1074;&#1089;&#1082;&#1072;&#1103; &#1091;&#1089;&#1072;&#1076;&#1100;&#1073;&#1072;&gt;')\">
                                    <img src=\"/pic/pixel.gif\" class=\"place2\" width=\"172\" height=\"152\" border=\"0\" alt=\"Карта, нажмите для увеличения\" />
                                </a>
                            </td>
                        </tr>
                    </table>
                    <p>
                        \"Шуваловская усадьба\" построена на Нижнем Большом Суздальском озере. Суздальские озера (Верхнее, Среднее и Нижнее Большое) расположены между Выборгским шоссе
                        и Новоорловским лесопарком и являются доминантой микрорайона.
                    </p>
                </span>
                <p>
                    Шувалово-Озерки один из наиболее привлекательных и бурно развивающихся районов Санкт-Петербурга, он находится в северной части города и входит в состав
                    Выборгского района. Ближайшие станции метро - \"Озерки\" и \"Проспект Просвещения\".
                </p>
                <p>
                    Четко отлаженная инфраструктура выгодно отличает Шувалово-Озерки от других районов Санкт-Петербурга: здесь построены лучшие школы, детские сады, фитнес-клубы и
                    лечебные учреждения. Здесь сосредоточены самые крупные гипермаркеты и торговые комплексы, среди которых \"О'Кей\", \"Лента\", \"Шувалово\", \"Норд\", \"Озерки\",
                    \"Космополис\", \"Гранд Каньон\".
                </p>
                <p>
                    Удобная транспортная развязка делает этот район одним из самых интересных. До выезда из города всего пять километров, и открывается сразу несколько направлений:
                    Выборгское, Приозерское шоссе и кольцевая автодорога, ведущая в сторону Сестрорецка и Кронштадта.
                </p>
            </td>
            <td class=\"contentTab2Td3\"></td>
        </tr>
        <tr>
            <td></td>
            <td class=\"contentTab2Td6\"><img src=\"/pic/pixel.gif\" width=\"6\" height=\"6\" border=\"0\" alt=\"\" /></td>
            <td class=\"contentTab2Td5\"><img src=\"/pic/pixel.gif\" width=\"150\" height=\"1\" border=\"0\" alt=\"\" /></td>
            <td class=\"contentTab2Td5\" style=\"width:100%;\"></td>
        </tr>
    </table>

";
    }

    public function getTemplateName()
    {
        return "structura.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 4,  28 => 3,  11 => 1,);
    }
}
