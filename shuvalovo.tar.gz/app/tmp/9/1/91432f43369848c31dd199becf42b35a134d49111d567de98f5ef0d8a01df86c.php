<?php

/* liter-b.html */
class __TwigTemplate_91432f43369848c31dd199becf42b35a134d49111d567de98f5ef0d8a01df86c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html", "liter-b.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "   
   <script type=\"text/javascript\" src=\"../jquery.js\"></script>
<script type=\"text/javascript\" src=\"../cboxmod.js\"></script>
<table class=\"contentTab\" style=\"width:750px\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
\t<tr> 
\t\t<td class=\"contentTabTd1\"></td> 
\t\t<td class=\"contentTabTd2\"></td>
\t</tr>
\t<tr> 
\t\t<td class=\"contentTabTd3\">
\t\t\t<div class=\"buildinfo\" id=\"liter_b\">
\t\t\t<p><b>ул. Первомайская, д.26 лит А</b></p><br>
\t\t\t<p><b>Квартира №4:</b><br><a href=\"/html/b4.html\" title=\"Подробнее\">Трёхуровневая квартира общей площадью 245,6 м<sup>2</sup></a></p><br>
\t\t\t<p><b>Квартира №5:</b><br><a href=\"/html/b5.html\" title=\"Подробнее\">Четырёхуровневая квартира с мансардным этажом<sup>&nbsp;</sup><br>общей площадью 316,7 м<sup>2</sup></a></p><br>
\t\t\t<p><b>Квартира №6:</b><br><a href=\"/html/b6.html\" title=\"Подробнее\">Четырёхуровневая квартира с мансардным этажом<sup>&nbsp;</sup><br>общей площадью 419,5 м<sup>2</sup></a></p><br>
\t\t\t<p style=\"text-indent:0\"><a href=\"/html/plan.html\" title=\"Планировки\" class=\"backlink\">Назад к планировкам</a></p>
\t\t\t</div>
\t\t\t<div class=\"buildfaces\">
\t\t\t\t<div class=\"buildface\">
\t\t\t\t\t<a href=\"?b_face1\" title=\"Увеличить\">
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"164\" height=\"96\" alt=\"литер B, фасад W\" id=\"b_face1\">
\t\t\t\t\t</a><br>Фасад дома &ndash; западная сторона
\t\t\t\t</div>
\t\t\t\t<div class=\"buildface\">
\t\t\t\t\t<a href=\"?b_face2\" title=\"Увеличить\">
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"164\" height=\"96\" alt=\"литер B, фасад N\" id=\"b_face2\">
\t\t\t\t\t</a><br>Фасад дома &ndash; северная сторона
\t\t\t\t</div>
\t\t\t</div>
\t\t</td> 
\t\t<td class=\"contentTabTd4\"></td>
\t</tr>
\t<tr> 
\t\t<td class=\"contentTabTd5\"></td> 
\t\t<td class=\"contentTabTd6\"></td>
\t</tr>
</table>
   
  ";
    }

    public function getTemplateName()
    {
        return "liter-b.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 4,  28 => 3,  11 => 1,);
    }
}
