<?php

/* liter-a.html */
class __TwigTemplate_61d35f05e6da1fcece879a421ea36bdca8396fb3069c1d9a823273d8baaf3626 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html", "liter-a.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "   
<script type=\"text/javascript\" src=\"/jquery.js\"></script>
<script type=\"text/javascript\" src=\"/cboxmod.js\"></script>
<table class=\"contentTab\" style=\"width:750px\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
\t<tr> 
\t\t<td class=\"contentTabTd1\"></td> 
\t\t<td class=\"contentTabTd2\"></td>
\t</tr>
\t<tr> 
\t\t<td class=\"contentTabTd3\">
\t\t\t<div class=\"buildinfo\" id=\"liter_a\">
\t\t\t<p><b>ул. Петровская, д.13, лит А</b></p><br>
\t\t\t<p><b>Квартира №1</b> <span class=\"price\">— 65.200 р./кв.м.</span><br><a href=\"/html/a1.html\" title=\"Подробнее\">Трёхуровневая квартира общей площадью 269,7 м<sup>2</sup></a></p><br>
\t\t\t<p><b>Квартира №2</b> <span class=\"price\">— 65.800 р./кв.м.</span><br><a href=\"/html/a2.html\" title=\"Подробнее\">Четырёхуровневая квартира с мансардным этажом<sup>&nbsp;</sup><br>общей площадью 379,9 м<sup>2</sup></a></p><br>
\t\t\t<p><b>Квартира №3</b> <span class=\"reserved\">— забронирована</span><br><a href=\"/html/a3.html\" title=\"Подробнее\">Трёхуровневая квартира общей площадью 269,4 м<sup>2</sup><br>с прямым видом на озеро<sup>&nbsp;</sup></a></p><br>
\t\t\t<p style=\"text-indent:0\"><a href=\"/html/plan.html\" title=\"Планировки\" class=\"backlink\">Назад к планировкам</a></p>
\t\t\t</div>
\t\t\t<div class=\"buildfaces\">
\t\t\t\t<div class=\"buildface\">
\t\t\t\t\t<a href=\"?a_face1\" title=\"Увеличить\">
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"164\" height=\"96\" alt=\"литер А, фасад NE\" id=\"a_face1\">
\t\t\t\t\t</a><br>Фасад дома &ndash; северо-восточная сторона
\t\t\t\t</div>
\t\t\t\t<div class=\"buildface\">
\t\t\t\t\t<a href=\"?a_face2\" title=\"Увеличить\">
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"164\" height=\"96\" alt=\"литер А, фасад NW\" id=\"a_face2\">
\t\t\t\t\t</a><br>Фасад дома &ndash; северо-западная сторона
\t\t\t\t</div>
\t\t\t</div>
\t\t</td> 
\t\t<td class=\"contentTabTd4\"></td>
\t</tr>
\t<tr> 
\t\t<td class=\"contentTabTd5\"></td> 
\t\t<td class=\"contentTabTd6\"></td>
\t</tr>
</table>
   
  ";
    }

    public function getTemplateName()
    {
        return "liter-a.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 4,  28 => 3,  11 => 1,);
    }
}
