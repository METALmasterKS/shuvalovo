<?php

/* a1.html */
class __TwigTemplate_248af2040828147ad33be5d95c7b9166f18ca100b1037cdce497ff554561b0c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html", "a1.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        echo "   
<script type=\"text/javascript\" src=\"../jquery.js\"></script>
<script type=\"text/javascript\" src=\"../cboxmod.js\"></script>
<table class=\"contentTab\" style=\"width:750px\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
\t<tr> 
\t\t<td class=\"contentTabTd1\"></td> 
\t\t<td class=\"contentTabTd2\"></td>
\t</tr>
\t<tr> 
\t\t<td class=\"contentTabTd3\">
\t\t\t<div class=\"buildinfo\" id=\"liter_a\">
\t\t\t\t<div class=\"flatinfo\">
\t\t\t\t\t<p><b>Квартира №1</b> <span class=\"price\">— 65.200 р./кв.м.</p>
\t\t\t\t\t<table class=\"sqrinfo\">
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>Общая площадь:</td> 
\t\t\t\t\t\t\t<td><strong>269,7 м<sup>2</sup></strong></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>Площадь квартиры 
\t\t\t\t\t\t\t<br>без технических помещений:</td> 
\t\t\t\t\t\t\t<td><strong>177 м<sup>2</sup></strong></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>Площадь цокольного этажа:</td> 
\t\t\t\t\t\t\t<td><strong>98,74 м<sup>2</sup></strong></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>Количество уровней:</td> 
\t\t\t\t\t\t\t<td><strong>3</strong></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</table>
\t\t\t\t\t<p>Вид из окон:
\t\t\t\t\t<br>&ndash; во двор
\t\t\t\t\t<br>&ndash; на соседний участок
\t\t\t\t\t<br>&ndash; под углом на озеро
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t\t<div class=\"otherlinks\">
\t\t\t\t\t<p>Другие квартиры в этом доме:</p>
\t\t\t\t\t<p><a href=\"/html/a2.html\" title=\"Четырёхуровневая квартира с мансардным этажом общей площадью 379,9 м&sup2;\">квартира №2</a></p>
\t\t\t\t\t<p><a href=\"/html/a3.html\" title=\"Трёхуровневая квартира общей площадью 269,4 м&sup2; с прямым видом на озеро\">квартира №3</a></p>
\t\t\t\t</div>
\t\t\t\t<p style=\"text-indent:0\"><a href=\"/html/liter-a.html\" title=\"Трёхквартирный дом, литер А (ул. Петровская, д.13, лит А)\" class=\"backlink\">Назад к описанию дома</a></p>
\t\t\t</div>
\t\t\t<div class=\"flatplans\">
\t\t\t\t<div class=\"shem1TabTd5 floorplan\">
\t\t\t\t\t<a href=\"?1a_2\" title=\"Подробнее\">Второй этаж<br>
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"254\" height=\"151\" class=\"shem6\" alt=\"2 этаж\"></a>
\t\t\t\t</div>
\t\t\t\t<div class=\"shem1TabTd4 floorplan\">
\t\t\t\t\t<a href=\"?1a_1\" title=\"Подробнее\">Первый этаж<br>
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"254\" height=\"151\" class=\"shem5\" alt=\"1 этаж\"></a>
\t\t\t\t</div>
\t\t\t\t<div class=\"shem1TabTd3 floorplan\">
\t\t\t\t\t<a href=\"?1a_0\" title=\"Подробнее\">Цокольный этаж<br>
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"254\" height=\"151\" class=\"shem4\" alt=\"Цокольный этаж\"></a>
\t\t\t\t</div>
\t\t\t</div>
\t\t</td> 
\t\t<td class=\"contentTabTd4\"></td>
\t</tr>
\t<tr> 
\t\t<td class=\"contentTabTd5\"></td> 
\t\t<td class=\"contentTabTd6\"></td>
\t</tr>
</table>
   
";
    }

    public function getTemplateName()
    {
        return "a1.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 4,  11 => 1,);
    }
}
