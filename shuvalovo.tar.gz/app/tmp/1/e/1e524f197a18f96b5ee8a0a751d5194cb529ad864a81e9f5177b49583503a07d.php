<?php

/* layouts/layout.html */
class __TwigTemplate_1e524f197a18f96b5ee8a0a751d5194cb529ad864a81e9f5177b49583503a07d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">
<html>
    <head>
        <title>«Усадьба у озера» – коттеджи, таунхаусы, квартиры в Санкт-Петербурге</title>
        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">
        <meta name=\"description\" content=\"Усадьба у озера – это определенный стиль жизни. Единое стилистическое и архитектурное решение фасадов, воссозданных по историческим аналогам, прекрасно сочетается с великолепием окружающей природы.\">
        <meta name=\"Keywords\" content=\"коттеджный посёлок петербург, продажа элитной недвижимости, элитные квартиры петербург, элитная недвижимость петербург,  продажа коттеджей петербург, танхаусы петербург, коттеджи, танхаусы, недвижимость, квартиры\">
        <meta name=\"Autor\" content=\"СИММЕТРИЯ (www.7i3.spb.ru) | РОДЕН – изменения и дополнения\">
        <base href=\"";
        // line 9
        echo twig_escape_filter($this->env, (isset($context["base_href"]) ? $context["base_href"] : null), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"css.css\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"cbox.css\">
        <!--[if lt IE 8]>
        <style type=\"text/css\">
        div.bg{background-position:center 3px}
        </style>
        <![endif]-->
        <script type=\"text/javascript\" src=\"scripts.js\"></script>
        <script type=\"text/javascript\">
            var _gaq = _gaq || [];
            _gaq.push(['_setAccount', 'UA-20049178-5']);
            _gaq.push(['_trackPageview']);
            (function () {
                var ga = document.createElement('script');
                ga.type = 'text/javascript';
                ga.async = true;
                ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(ga, s);
            })();
        </script>
    </head>
    <body>
        <div class=\"bg\">
            <table class=\"topNavTab\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
                <tr>
                    <td colspan=\"2\" class=\"cost\">
                        <a href=\"";
        // line 37
        echo twig_escape_filter($this->env, (isset($context["base_href"]) ? $context["base_href"] : null), "html", null, true);
        echo "\" title=\"На главную\"><img src=\"pic/logo.png\" width=\"342\" height=\"74\" alt=\"\"></a>
                    </td>
                    <td colspan=\"2\">
                        <span class=\"skidka\">
                            <a style=\"display: none;\" href=\"html/plan.html\">Летняя акция: скидка 15%!</a></span>
                        <img src=\"pic/akcija.jpg\" />
                    </td>
                    <td colspan=\"5\">
                        <span class=\"phone\">тел. (812) 670-0-670</span>
                    </td>

                    <!--<td colspan=\"5\" style=\"text-align:right;padding-right:20px\">
                    </td>-->
                </tr>
                <tr>
                    ";
        // line 52
        $context["marker"] = 1;
        // line 53
        echo "                    ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["navigation"]) ? $context["navigation"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 54
            echo "                        <td class=\"topNavTabTd";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\">
                            ";
            // line 55
            if ($this->getAttribute($context["item"], "html", array(), "any", true, true)) {
                // line 56
                echo "                                ";
                echo $this->getAttribute($context["item"], "html", array());
                echo "
                            ";
            } else {
                // line 58
                echo "                                ";
                if (($this->getAttribute($context["item"], "href", array()) == (isset($context["uri"]) ? $context["uri"] : null))) {
                    // line 59
                    echo "                                <a href=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "href", array()), "html", null, true);
                    echo "\" title=\"Описание\">
                                    <img src=\"/pic/pixel.gif\" class=\"marker";
                    // line 60
                    echo twig_escape_filter($this->env, (isset($context["marker"]) ? $context["marker"] : null), "html", null, true);
                    echo "On\" width=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "w", array()), "html", null, true);
                    echo "\" height=\"45\" alt=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
                    echo "\">
                                </a>
                                ";
                } else {
                    // line 63
                    echo "                                <a class=\"marker";
                    echo twig_escape_filter($this->env, (isset($context["marker"]) ? $context["marker"] : null), "html", null, true);
                    echo "\" onMouseOver=\"changePicOn('marker";
                    echo twig_escape_filter($this->env, (isset($context["marker"]) ? $context["marker"] : null), "html", null, true);
                    echo "1')\" onMouseOut=\"changePicOut('marker";
                    echo twig_escape_filter($this->env, (isset($context["marker"]) ? $context["marker"] : null), "html", null, true);
                    echo "1')\" href=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "href", array()), "html", null, true);
                    echo "\" title=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
                    echo "\">
                                    <img src=\"pic/pixel.gif\" width=\"";
                    // line 64
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "w", array()), "html", null, true);
                    echo "\" height=\"45\" alt=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
                    echo "\">
                                </a>
                                ";
                }
                // line 67
                echo "                                ";
                $context["marker"] = ((isset($context["marker"]) ? $context["marker"] : null) + 1);
                // line 68
                echo "                            ";
            }
            // line 69
            echo "                        </td>
                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 71
        echo "                </tr>
                <tr>
                    ";
        // line 73
        $context["marker"] = 1;
        // line 74
        echo "                    ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["navigation"]) ? $context["navigation"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 75
            echo "                        <td class=\"topNavTabTd";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "2\">
                            ";
            // line 76
            if ($this->getAttribute($context["item"], "html", array(), "any", true, true)) {
                // line 77
                echo "                                &nbsp;
                            ";
            } else {
                // line 79
                echo "                                ";
                if (($this->getAttribute($context["item"], "href", array()) == (isset($context["uri"]) ? $context["uri"] : null))) {
                    // line 80
                    echo "                                    <img src=\"/pic/pixel.gif\" id=\"marker";
                    echo twig_escape_filter($this->env, (isset($context["marker"]) ? $context["marker"] : null), "html", null, true);
                    echo "1\" class=\"marker";
                    echo twig_escape_filter($this->env, (isset($context["marker"]) ? $context["marker"] : null), "html", null, true);
                    echo "1On\" width=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "w", array()), "html", null, true);
                    echo "\" height=\"31\" alt=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
                    echo "\">
                                ";
                } else {
                    // line 82
                    echo "                                    <img src=\"/pic/pixel.gif\" id=\"marker";
                    echo twig_escape_filter($this->env, (isset($context["marker"]) ? $context["marker"] : null), "html", null, true);
                    echo "1\" class=\"marker";
                    echo twig_escape_filter($this->env, (isset($context["marker"]) ? $context["marker"] : null), "html", null, true);
                    echo "1\" width=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "w", array()), "html", null, true);
                    echo "\" height=\"31\" alt=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
                    echo "\">
                                ";
                }
                // line 84
                echo "                                ";
                $context["marker"] = ((isset($context["marker"]) ? $context["marker"] : null) + 1);
                // line 85
                echo "                            ";
            }
            // line 86
            echo "                        </td>
                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 88
        echo "                </tr>
                <tr>
                    <td class=\"topNavTabTdContent\" colspan=\"9\">
                        ";
        // line 91
        $this->displayBlock('content', $context, $blocks);
        // line 92
        echo "                    </td>
                </tr>
                <tr>
                    <td class=\"topNavTabTdBottom\">
                    </td>
                    <td class=\"qq1\" colspan=\"8\">
                        Copyright © 2002-2013 <a href=\"";
        // line 98
        echo twig_escape_filter($this->env, (isset($context["base_href"]) ? $context["base_href"] : null), "html", null, true);
        echo "\" title=\"Продажа элитной недвижимости, квартиры Петербурга\">Продажа элитной недвижимости, квартиры Петербурга</a><br>
                        <a href=\"mailto:t.volinskaya@gmail.com\" rel=\"nofollow\">Дизайн: Татьяна Волынская</a>
                        Разработка: СИММЕТРИЯ | РОДЕН
                    </td>
                </tr>
            </table>
            <!-- Yandex.Metrika counter -->
            <script type=\"text/javascript\">
                              (function (d, w, c) {
                                  (w[c] = w[c] || []).push(function () {
                                      try {
                                          w.yaCounter24831233 = new Ya.Metrika({id: 24831233,
                                              webvisor: true,
                                              clickmap: true,
                                              trackLinks: true,
                                              accurateTrackBounce: true});
                                      } catch (e) {
                                      }
                                  });

                                  var n = d.getElementsByTagName(\"script\")[0],
                                          s = d.createElement(\"script\"),
                                          f = function () {
                                              n.parentNode.insertBefore(s, n);
                                          };
                                  s.type = \"text/javascript\";
                                  s.async = true;
                                  s.src = (d.location.protocol == \"https:\" ? \"https:\" : \"http:\") + \"//mc.yandex.ru/metrika/watch.js\";

                                  if (w.opera == \"[object Opera]\") {
                                      d.addEventListener(\"DOMContentLoaded\", f, false);
                                  } else {
                                      f();
                                  }
                              })(document, window, \"yandex_metrika_callbacks\");
            </script>
            <noscript><div><img src=\"http://mc.yandex.ru/watch/24831233\" style=\"position:absolute; left:-9999px;\" alt=\"\" /></div></noscript>
            <!-- /Yandex.Metrika counter -->
            <!-- Yandex.Metrika counter -->
            <script type=\"text/javascript\">
                (function (d, w, c) {
                    (w[c] = w[c] || []).push(function () {
                        try {
                            w.yaCounter20819431 = new Ya.Metrika({id: 20819431,
                                clickmap: true,
                                trackLinks: true,
                                accurateTrackBounce: true});
                        } catch (e) {
                        }
                    });

                    var n = d.getElementsByTagName(\"script\")[0],
                            s = d.createElement(\"script\"),
                            f = function () {
                                n.parentNode.insertBefore(s, n);
                            };
                    s.type = \"text/javascript\";
                    s.async = true;
                    s.src = (d.location.protocol == \"https:\" ? \"https:\" : \"http:\") + \"//mc.yandex.ru/metrika/watch.js\";

                    if (w.opera == \"[object Opera]\") {
                        d.addEventListener(\"DOMContentLoaded\", f, false);
                    } else {
                        f();
                    }
                })(document, window, \"yandex_metrika_callbacks\");
            </script>
            <noscript><div><img src=\"http://mc.yandex.ru/watch/20819431\" style=\"position:absolute; left:-9999px;\" alt=\"\" /></div></noscript>
            <!-- /Yandex.Metrika counter -->
        </div>
    </body>
</html>
";
    }

    // line 91
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "layouts/layout.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  347 => 91,  270 => 98,  262 => 92,  260 => 91,  255 => 88,  240 => 86,  237 => 85,  234 => 84,  222 => 82,  210 => 80,  207 => 79,  203 => 77,  201 => 76,  196 => 75,  178 => 74,  176 => 73,  172 => 71,  157 => 69,  154 => 68,  151 => 67,  143 => 64,  130 => 63,  120 => 60,  115 => 59,  112 => 58,  106 => 56,  104 => 55,  99 => 54,  81 => 53,  79 => 52,  61 => 37,  30 => 9,  20 => 1,);
    }
}
