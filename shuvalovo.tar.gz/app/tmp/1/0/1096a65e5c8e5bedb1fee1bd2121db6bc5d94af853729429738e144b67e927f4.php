<?php

/* contacts.html */
class __TwigTemplate_1096a65e5c8e5bedb1fee1bd2121db6bc5d94af853729429738e144b67e927f4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html", "contacts.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "
<table class=\"contentTab2\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
    <tr>
        <td style=\"width:700px;line-height:0\"><img src=\"/pic/pixel.gif\" width=\"700\" height=\"1\" border=\"0\" alt=\"\" /></td>
        <td class=\"contentTab2Td2\"><img src=\"/pic/pixel.gif\" width=\"6\" height=\"6\" border=\"0\" alt=\"\" /></td>
        <td class=\"contentTab2Td1\"></td>
        <td class=\"contentTab2Td1\"></td>

    </tr>
    <tr>
        <td></td>
        <td class=\"contentTab2Td4\"></td>
        <td class=\"contentTab2Td3\" style=\"width:265px;\">
            <!--<p style=\"padding:8px; display:block;\"><strong>Эксклюзивный риэлтор
<br>  группа компаний \"Экотон\"</strong><br>
            (812) 325-16-99<br>
www: <a href=\"http://ecoton.spb.ru\">http://ecoton.spb.ru</a></p><br>-->

            <p style=\"padding:8px; display:block;\"><strong>ГК «Экотон»</strong><br>
                +7(812)325-16-99<br>
                
            </p>
            <span style=\"padding:8px; display:block;\">
                <ul style=\"color:red;\">";
        // line 27
        echo $this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "error", array());
        echo "</ul>
                ";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "success", array()), "html", null, true);
        echo "
                <form name=\"sendForm\" action=\"\" method=\"post\">
                    <table class=\"formTab\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
                        <tr>
                            <td><input type=\"text\" name=\"n585\" class=\"type1\" value=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : null), "n585", array()), "html", null, true);
        echo "\" placeholder=\"Имя\"></td>
                        </tr>
                        <tr>
                            <td><input type=\"text\" name=\"m585\" class=\"type1\" value=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : null), "m585", array()), "html", null, true);
        echo "\" placeholder=\"E-mail\"></td>
                        </tr>
                        <tr>
                            <td><textarea name=\"t585\" rows=\"4\" class=\"type2\" wrap=\"VIRTUAL\" placeholder=\"Ваше сообщение\">";
        // line 38
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : null), "t585", array()), "html", null, true);
        echo "</textarea></td>
                        </tr>
                        <tr>
                            <td><input name=\"\" title=\"Отправить\" alt=\"Отправить\" type=\"image\" src=\"../pic/send_button.jpg\"></td>
                        </tr>
                    </table>
                </form>
            </span> </td>
        <td class=\"contentTab2Td3\"></td>
    </tr>
    <tr>
        <td></td>
        <td class=\"contentTab2Td6\"><img src=\"/pic/pixel.gif\" width=\"6\" height=\"6\" border=\"0\" alt=\"\" /></td>
        <td class=\"contentTab2Td5\"><img src=\"/pic/pixel.gif\" width=\"265\" height=\"1\" border=\"0\" alt=\"\" /></td>
        <td class=\"contentTab2Td5\" style=\"width:100%;\"></td>
    </tr>
</table>

";
    }

    public function getTemplateName()
    {
        return "contacts.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 38,  73 => 35,  67 => 32,  60 => 28,  56 => 27,  31 => 4,  28 => 3,  11 => 1,);
    }
}
