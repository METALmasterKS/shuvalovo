<?php

/* b5.html */
class __TwigTemplate_15d45e773c26cfd27c9a6296105d77c8aa8d814fe116204e1777f696de1123d1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html", "b5.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "   
   <script type=\"text/javascript\" src=\"../jquery.js\"></script>
<script type=\"text/javascript\" src=\"../cboxmod.js\"></script>
<table class=\"contentTab\" style=\"width:1000px\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
\t<tr> 
\t\t<td class=\"contentTabTd1\"></td> 
\t\t<td class=\"contentTabTd2\"></td>
\t</tr>
\t<tr> 
\t\t<td class=\"contentTabTd3\">
\t\t\t<div class=\"buildinfo\" id=\"liter_b\">
\t\t\t\t<div class=\"flatinfo\">
\t\t\t\t\t<p><b>Квартира №5</b> <span class=\"price\">— 54.900 р./кв.м.</span></p>
\t\t\t\t\t<table class=\"sqrinfo\">
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>Общая площадь:</td> 
\t\t\t\t\t\t\t<td><strong>316,7 м<sup>2</sup></strong></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>Площадь квартиры 
\t\t\t\t\t\t\t<br>без технических помещений:</td> 
\t\t\t\t\t\t\t<td><strong>209,7 м<sup>2</sup></strong></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>Площадь цокольного этажа:</td> 
\t\t\t\t\t\t\t<td><strong>85,97 м<sup>2</sup></strong></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>Количество уровней:</td> 
\t\t\t\t\t\t\t<td><strong>4</strong></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</table>
\t\t\t\t\t<p>Вид из окон:
\t\t\t\t\t<br>&ndash; с 1-го этажа: на улицу Первомайская
\t\t\t\t\t<br>&ndash; со 2-го этажа: во двор и на улицу Первомайская
\t\t\t\t\t<br>&ndash; с мансардного этажа: на улицу и через двор на озеро
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t\t<div class=\"otherlinks\">
\t\t\t\t\t<p>Другие квартиры в этом доме:</p>
\t\t\t\t\t<p><a href=\"/html/b4.html\" title=\"Трёхуровневая квартира общей площадью 245,6 м&sup2;\">квартира №4</a></p>
\t\t\t\t\t<p><a href=\"/html/b6.html\" title=\"Четырёхуровневая квартира с мансардным этажом общей площадью 419,5 м&sup2;\">квартира №6</a></p>
\t\t\t\t</div>
\t\t\t<p style=\"text-indent:0\"><a href=\"/html/liter-b.html\" title=\"Трёхквартирный дом, литер Б (ул. Первомайская, д.26 лит А)\" class=\"backlink\">Назад к описанию дома</a></p>
\t\t\t</div>
\t\t\t<div class=\"flatplans\" style=\"width:554px\">
\t\t\t\t<div style=\"float:right\" class=\"shem1TabTd5 floorplan\">
\t\t\t\t\t<a href=\"?5b_3\" title=\"Подробнее\">Мансардный этаж<br>
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"254\" height=\"151\" class=\"shem17\" alt=\"Мансардный этаж\"></a>
\t\t\t\t</div>
\t\t\t\t<div class=\"shem1TabTd5 floorplan\">
\t\t\t\t\t<a href=\"?5b_2\" title=\"Подробнее\">Второй этаж<br>
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"254\" height=\"151\" class=\"shem16\" alt=\"2 этаж\"></a>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"flatplans\" style=\"padding-top:0\">
\t\t\t\t<div class=\"shem1TabTd4 floorplan\">
\t\t\t\t\t<a href=\"?5b_1\" title=\"Подробнее\">Первый этаж<br>
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"254\" height=\"151\" class=\"shem15\" alt=\"1 этаж\"></a>
\t\t\t\t</div>
\t\t\t\t<div class=\"shem1TabTd3 floorplan\">
\t\t\t\t\t<a href=\"?5b_0\" title=\"Подробнее\">Цокольный этаж<br>
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"254\" height=\"151\" class=\"shem14\" alt=\"Цокольный этаж\"></a>
\t\t\t\t</div> 
\t\t\t</div>
\t\t</td> 
\t\t<td class=\"contentTabTd4\"></td>
\t</tr>
\t<tr> 
\t\t<td class=\"contentTabTd5\"></td> 
\t\t<td class=\"contentTabTd6\"></td>
\t</tr>
</table>
   
  ";
    }

    public function getTemplateName()
    {
        return "b5.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 4,  28 => 3,  11 => 1,);
    }
}
