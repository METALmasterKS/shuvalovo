<?php

/* map.html */
class __TwigTemplate_176b8976f5e3013f7830112c889757e20327efe3b0c72a166339d0df34315bd9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html", "map.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "   
               <table class=\"contentTab2\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
\t\t\t  <tr>
\t\t\t  \t<td style=\"width:680px;line-height:0\"><img src=\"/pic/pixel.gif\" width=\"680\" height=\"1\" alt=\"\"></td>
\t\t\t  \t<td class=\"contentTab2Td2\"></td>
\t\t\t\t<td class=\"contentTab2Td1\"></td>
\t\t\t\t<td class=\"contentTab2Td1\"></td>
\t\t\t\t
\t\t\t  </tr>
\t\t\t  <tr>
\t\t\t \t<td></td>
\t\t\t  \t<td class=\"contentTab2Td4\"></td>
\t\t\t\t<td class=\"contentTab2Td3\" style=\"padding:20px 0 30px 40px\">
\t\t\t\t\t<a href=\"";
        // line 17
        echo twig_escape_filter($this->env, (isset($context["base_href"]) ? $context["base_href"] : null), "html", null, true);
        echo "\">Главная</a>
\t\t\t\t\t<ul>
\t\t\t\t\t\t<li><a href=\"../html/desc.html\">Описание</a></li>
\t\t\t\t\t\t<li><a href=\"../html/plan.html\">Планировки</a>
\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t<li><a href=\"../html/liter-a.html\">Трехквартирный дом литер А</a>
\t\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t<li><a href=\"../html/a1.html\">Квартира №1</a></li>
\t\t\t\t\t\t\t\t\t<li><a href=\"../html/a2.html\">Квартира №2</a></li>
\t\t\t\t\t\t\t\t\t<li><a href=\"../html/a3.html\">Квартира №3</a></li>
\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li><a href=\"../html/liter-b.html\">Трехквартирный дом литер B</a>
\t\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t<li><a href=\"../html/b4.html\">Квартира №4</a></li>
\t\t\t\t\t\t\t\t\t<li><a href=\"../html/b5.html\">Квартира №5</a></li>
\t\t\t\t\t\t\t\t\t<li><a href=\"../html/b6.html\">Квартира №6</a></li>
\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li><a href=\"../html/liter-c.html\">Двухквартирный дом литер C</a>
\t\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t<li><a href=\"../html/c7.html\">Квартира №7</a></li>
\t\t\t\t\t\t\t\t\t<li><a href=\"../html/c8.html\">Квартира №8</a></li>
\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li><a href=\"../html/photo.html\">Фотографии</a></li>
\t\t\t\t\t\t<li><a href=\"../html/structura.html\">Инфраструктура</a></li>
\t\t\t\t\t\t<li><a href=\"../html/contacts.html\">Контакты</a></li>
\t\t\t\t\t</ul>
\t\t        \t</td>
\t\t\t\t<td class=\"contentTab2Td3\"></td>
\t\t\t  </tr>
\t\t\t  <tr>
\t\t\t  \t<td></td>
\t\t\t \t<td class=\"contentTab2Td6\"><img src=\"/pic/pixel.gif\" width=\"6\" height=\"6\" alt=\"\"></td>
\t\t\t\t<td class=\"contentTab2Td5\"><img src=\"/pic/pixel.gif\" width=\"290\" height=\"1\" alt=\"\"></td>
\t\t\t\t<td class=\"contentTab2Td5\" style=\"width:100%;\"></td>
\t\t\t  </tr>
\t\t  </table>
   
  ";
    }

    public function getTemplateName()
    {
        return "map.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  46 => 17,  31 => 4,  28 => 3,  11 => 1,);
    }
}
