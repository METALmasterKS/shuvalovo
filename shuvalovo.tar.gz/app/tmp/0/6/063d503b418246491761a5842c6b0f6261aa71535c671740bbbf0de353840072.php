<?php

/* photo.html */
class __TwigTemplate_063d503b418246491761a5842c6b0f6261aa71535c671740bbbf0de353840072 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html", "photo.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        // line 5
        echo "
<table class=\"contentTab\" style=\"width:930px;\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
    <tr>
        <td class=\"contentTabTd1\"></td>
        <td class=\"contentTabTd2\"><img src=\"/pic/pixel.gif\" width=\"6\" height=\"6\" border=\"0\" alt=\"\" /></td>
    </tr>
    <tr>
        <td class=\"contentTabTd3\">
            <table border=\"0\" style=\"width:100%;\" cellspacing=\"0\" cellpadding=\"0\">
                <tr>
                    <td style=\"width:303px;\">
                        <table class=\"photoTab\" cellpadding=\"0\" cellspacing=\"5\" border=\"0\">
                            <tr>
                                <td class=\"photoTabPrev1\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix1', '31082009222', 'on')\" onMouseOut=\"loadPics('TrPix1', '31082009222', 'out')\" onClick=\"loadPics('TrPix1', '31082009222', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix1\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                                <td class=\"photoTabPrev2\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix2', 'IMG_2942', 'on')\" onMouseOut=\"loadPics('TrPix2', 'IMG_2942', 'out')\" onClick=\"loadPics('TrPix2', 'IMG_2942', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix2\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                                <td class=\"photoTabPrev3\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix3', 'IMG_2943', 'on')\" onMouseOut=\"loadPics('TrPix3', 'IMG_2943', 'out')\" onClick=\"loadPics('TrPix3', 'IMG_2943', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix3\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                                <td class=\"photoTabPrev4\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix4', 'IMG_2944', 'on')\" onMouseOut=\"loadPics('TrPix4', 'IMG_2944', 'out')\" onClick=\"loadPics('TrPix4', 'IMG_2944', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix4\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                            </tr>
                            <tr>
                                <td class=\"photoTabPrev5\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix5', 'IMG_2946', 'on')\" onMouseOut=\"loadPics('TrPix5', 'IMG_2946', 'out')\" onClick=\"loadPics('TrPix5', 'IMG_2946', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix5\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                                <td class=\"photoTabPrev6\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix6', 'IMG_2947', 'on')\" onMouseOut=\"loadPics('TrPix6', 'IMG_2947', 'out')\" onClick=\"loadPics('TrPix6', 'IMG_2947', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix6\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                                <td class=\"photoTabPrev7\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix7', '0026', 'on')\" onMouseOut=\"loadPics('TrPix7', '0026', 'out')\" onClick=\"loadPics('TrPix7', '0026', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix7\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                                <td class=\"photoTabPrev8\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix8', 'IMG_2949', 'on')\" onMouseOut=\"loadPics('TrPix8', 'IMG_2949', 'out')\" onClick=\"loadPics('TrPix8', 'IMG_2949', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix8\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                            </tr>
                            <tr>
                                <td class=\"photoTabPrev9\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix9', 'IMG_2950', 'on')\" onMouseOut=\"loadPics('TrPix9', 'IMG_2950', 'out')\" onClick=\"loadPics('TrPix9', 'IMG_2950', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix9\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                                <td class=\"photoTabPrev10\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix10', 'IMG_1473', 'on')\" onMouseOut=\"loadPics('TrPix10', 'IMG_1473', 'out')\" onClick=\"loadPics('TrPix10', 'IMG_1473', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix10\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                                <td class=\"photoTabPrev11\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix11', 'IMG_2953', 'on')\" onMouseOut=\"loadPics('TrPix11', 'IMG_2953', 'out')\" onClick=\"loadPics('TrPix11', 'IMG_2953', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix11\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                                <td class=\"photoTabPrev12\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix12', 'IMG_2954', 'on')\" onMouseOut=\"loadPics('TrPix12', 'IMG_2954', 'out')\" onClick=\"loadPics('TrPix12', 'IMG_2954', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix12\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                            </tr>
                            <tr>
                                <td class=\"photoTabPrev13\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix13', 'IMG_2955', 'on')\" onMouseOut=\"loadPics('TrPix13', 'IMG_2955', 'out')\" onClick=\"loadPics('TrPix13', 'IMG_2955', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix13\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                                <td class=\"photoTabPrev14\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix14', 'IMG_2956', 'on')\" onMouseOut=\"loadPics('TrPix14', 'IMG_2956', 'out')\" onClick=\"loadPics('TrPix14', 'IMG_2956', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix14\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                                <td class=\"photoTabPrev15\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix15', 'IMG_2957', 'on')\" onMouseOut=\"loadPics('TrPix15', 'IMG_2957', 'out')\" onClick=\"loadPics('TrPix15', 'IMG_2957', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix15\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                                <td class=\"photoTabPrev16\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix16', 'IMG_2958', 'on')\" onMouseOut=\"loadPics('TrPix16', 'IMG_2958', 'out')\" onClick=\"loadPics('TrPix16', 'IMG_2958', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix16\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                            </tr>
                            <tr>
                                <td class=\"photoTabPrev17\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix17', 'IMG_2959', 'on')\" onMouseOut=\"loadPics('TrPix17', 'IMG_2959', 'out')\" onClick=\"loadPics('TrPix17', 'IMG_2959', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix17\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                                <td class=\"photoTabPrev18\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix18', 'IMG_2961', 'on')\" onMouseOut=\"loadPics('TrPix18', 'IMG_2961', 'out')\" onClick=\"loadPics('TrPix18', 'IMG_2961', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix18\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                                <td class=\"photoTabPrev19\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix19', 'IMG_2962', 'on')\" onMouseOut=\"loadPics('TrPix19', 'IMG_2962', 'out')\" onClick=\"loadPics('TrPix19', 'IMG_2962', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix19\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                                <td class=\"photoTabPrev20\"><a href=\"javascript:void(0)\" onMouseOver=\"loadPics('TrPix20', 'IMG_2963', 'on')\" onMouseOut=\"loadPics('TrPix20', 'IMG_2963', 'out')\" onClick=\"loadPics('TrPix20', 'IMG_2963', 'in')\"><img src=\"/pic/pixel.gif\" id=\"TrPix20\" width=\"70\" height=\"70\" class=\"TrPix1\" border=\"0\" alt=\"\" /></a></td>
                            </tr>
                        </table>
                    </td>
                    <td style=\"text-align:center;\"><span class=\"fullIMG\" id=\"fullIMG\"><img src=\"../pic/photo/default_pic.jpg\" id=\"fullIMGimg\" class=\"fullIMGOn\" border=\"0\" alt=\"\" /></span></td>
                </tr>
            </table></td>
        <td class=\"contentTabTd4\"></td>

    </tr>
    <tr>
        <td class=\"contentTabTd5\"><img src=\"/pic/pixel.gif\" width=\"6\" height=\"6\" border=\"0\" alt=\"\" /></td>
        <td class=\"contentTabTd6\"></td>
    </tr>
</table>

";
    }

    public function getTemplateName()
    {
        return "photo.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 5,  28 => 4,  11 => 1,);
    }
}
