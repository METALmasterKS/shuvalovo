<?php

/* plan.html */
class __TwigTemplate_e04afb34fb56d3f0d0ad392ec01af63891c4f70b8cc829c7060315194b6ae622 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html", "plan.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        // line 5
        echo "   
   <script type=\"text/javascript\" src=\"../scriptsShems.js\"></script>
<script type=\"text/javascript\">function hilight(id){document.getElementById('buildsmap').style.backgroundPosition='-'+id*360+'px 5px'}</script>
<table class=\"contentTab\" style=\"width:850px;\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
<tr>
<td class=\"contentTabTd1\"></td>
<td class=\"contentTabTd2\"></td>
</tr>
<tr>
<td class=\"contentTabTd3\">
<div id=\"buildsinfo\">
\t<div class=\"builds\" id=\"build1\">
\t<a href=\"../html/liter-a.html\" title=\"Показать информацию о доме (ул. Петровская, д.13, лит А)\" class=\"buildlink\" id=\"liter_a\" onMouseOver=\"hilight('1')\" onMouseOut=\"hilight('0')\">
\t\t<img src=\"/pic/pixel.gif\" width=\"336\" height=\"32\" alt=\"Трехквартирный дом литер А\"></a>
\t<p class=\"flatlink\"><a href=\"/html/a1.html\" title=\"Трёхуровневая квартира общей площадью 269,7 м&sup2;\">Квартира №1</a> – <b class=\"price\">65.200 р./кв.м.</b></p>
\t<p class=\"flatlink\"><a href=\"/html/a2.html\" title=\"Четырёхуровневая квартира с мансардным этажом общей площадью 379,9 м&sup2;\">Квартира №2</a> – <b class=\"price\">65.800 р./кв.м.</b></p>
\t<p class=\"flatlink\"><a href=\"/html/a3.html\" title=\"Трёхуровневая квартира общей площадью 269,4 м&sup2; с прямым видом на озеро\">Квартира №3</a> – <b class=\"reserved\">забронирована</b></p>
\t</div>
\t<div class=\"builds\" id=\"build2\">
\t<a href=\"../html/liter-b.html\" title=\"Показать информацию о доме (ул. Первомайская, д.26 лит А)\" class=\"buildlink\" id=\"liter_b\" onMouseOver=\"hilight('2')\" onMouseOut=\"hilight('0')\">
\t\t<img src=\"/pic/pixel.gif\" width=\"328\" height=\"32\" alt=\"Трехквартирный дом литер B\"></a>
\t<p class=\"flatlink\"><a href=\"/html/b4.html\" title=\"Трёхуровневая квартира общей площадью 245,6 м&sup2;\">Квартира №4</a> – <b class=\"reserved\">забронирована</b></p>
\t<p class=\"flatlink\"><a href=\"/html/b5.html\" title=\"Четырёхуровневая квартира с мансардным этажом общей площадью 316,7 м&sup2;\">Квартира №5</a> – <b class=\"price\">54.900 р./кв.м.</b></p>
\t<p class=\"flatlink\"><a href=\"/html/b6.html\" title=\"Четырёхуровневая квартира с мансардным этажом общей площадью 419,5 м&sup2;\">Квартира №6</a> – <b class=\"price\">46.500 р./кв.м.</b></p>
\t</div>
\t<div class=\"builds\" id=\"build3\">
\t<a href=\"../html/liter-c.html\" title=\"Показать информацию о доме (ул. Петровская, д.15, лит А)\" class=\"buildlink\" id=\"liter_c\" onMouseOver=\"hilight('3')\" onMouseOut=\"hilight('0')\">
\t\t<img src=\"/pic/pixel.gif\" width=\"320\" height=\"32\" alt=\"Двухквартирный дом литер C\"></a>
\t<p class=\"flatlink\"><a href=\"/html/c7.html\" title=\"Трёхуровневая квартира общей площадью 320,7 м&sup2; с прямым видом на озеро\">Квартира №7</a> – <b class=\"sold\">продана</b></p>
\t<p class=\"flatlink\"><a href=\"/html/c8.html\" title=\"Четырёхуровневая квартира с мансардным этажом общей площадью 374,5 м&sup2;\">Квартира №8</a> – <b class=\"sold\">продана</b></p>
\t</div>
</div>
<div id=\"buildsmap\">
\t<img src=\"/pic/pixel.gif\" width=\"360\" height=\"435\" alt=\"Планировка\" usemap=\"#builds\">
\t<map name=\"builds\">
\t<area shape=\"poly\" coords=\"225,396,204,380,199,382,189,374,189,369,181,362,176,364,166,356,166,351,146,336,152,328,148,326,148,318,153,312,160,312,163,314,169,307,159,299,164,293,168,296,174,290,180,291,201,308,208,307,213,311,219,312,220,321,214,328,220,333,218,336,224,339,220,345,234,356,232,360,245,370\" title=\"Трёхквартирный дом, литер А (ул. Петровская, д.13, лит А)\" alt=\"Трёхквартирный дом, литер А\" href=\"../html/liter-a.html\" onMouseOver=\"hilight('1')\" onMouseOut=\"hilight('0')\">
\t<area shape=\"poly\" coords=\"285,337,280,321,275,321,263,315,261,307,267,305,260,284,254,286,247,265,253,263,250,253,260,238,266,237,272,241,298,232,306,256,310,258,313,269,311,273,314,285,319,286,322,298,319,301,326,324\" title=\"Трёхквартирный дом, литер Б (ул. Первомайская, д.26 лит А)\" alt=\"Трёхквартирный дом, литер Б\" href=\"../html/liter-b.html\" onMouseOver=\"hilight('2')\" onMouseOut=\"hilight('0')\">
\t<area shape=\"poly\" coords=\"195,247,197,244,195,241,166,235,162,229,164,215,161,211,163,200,169,196,173,174,181,175,188,167,197,169,201,174,200,179,229,186,228,191,233,191,226,222,219,228,212,227,207,231,206,245,203,248\" title=\"Двухквартирный дом, литер С (ул. Петровская, д.15, лит А)\" alt=\"Двухквартирный дом, литер С\" href=\"../html/liter-c.html\" onMouseOver=\"hilight('3')\" onMouseOut=\"hilight('0')\">
\t</map>
</div>
</td>
<td class=\"contentTabTd4\"></td>
</tr>
<tr>
<td class=\"contentTabTd5\">
<img src=\"/pic/pixel.gif\" width=\"6\" height=\"6\" alt=\"\"></td>
<td class=\"contentTabTd6\">
</td>
</tr>
</table>
   
";
    }

    public function getTemplateName()
    {
        return "plan.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 5,  28 => 4,  11 => 1,);
    }
}
