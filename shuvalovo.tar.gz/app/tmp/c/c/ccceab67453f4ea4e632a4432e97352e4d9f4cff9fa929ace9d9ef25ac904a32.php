<?php

/* liter-c.html */
class __TwigTemplate_ccceab67453f4ea4e632a4432e97352e4d9f4cff9fa929ace9d9ef25ac904a32 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html", "liter-c.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "   
   <script type=\"text/javascript\" src=\"../jquery.js\"></script>
<script type=\"text/javascript\" src=\"../cboxmod.js\"></script>
<table class=\"contentTab\" style=\"width:750px\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
\t<tr> 
\t\t<td class=\"contentTabTd1\"></td> 
\t\t<td class=\"contentTabTd2\"></td>
\t</tr>
\t<tr> 
\t\t<td class=\"contentTabTd3\">
\t\t\t<div class=\"buildinfo\" id=\"liter_c\">
\t\t\t<p><b>ул. Петровская, д.15, лит А</b></p><br>
\t\t\t<p><b>Квартира №7:</b><br><a href=\"/html/c7.html\" title=\"Подробнее\">Трёхуровневая квартира общей площадью 320,7 м<sup>2</sup><br>с прямым видом на озеро<sup>&nbsp;</sup></a></p><br>
\t\t\t<p><b>Квартира №8:</b><br><a href=\"/html/c8.html\" title=\"Подробнее\">Четырёхуровневая квартира с мансардным этажом<sup>&nbsp;</sup><br>общей площадью 374,5 м<sup>2</sup></a></p><br>
\t\t\t<p style=\"text-indent:0\"><a href=\"/html/plan.html\" title=\"Планировки\" class=\"backlink\">Назад к планировкам</a></p>
\t\t\t</div>
\t\t\t<div class=\"buildfaces\">
\t\t\t\t<div class=\"buildface\">
\t\t\t\t\t<a href=\"?c_face1\" title=\"Увеличить\">
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"164\" height=\"96\" alt=\"литер А, фасад SE\" id=\"c_face1\">
\t\t\t\t\t</a><br>Фасад дома &ndash; юго-восточная сторона
\t\t\t\t</div>
\t\t\t\t<div class=\"buildface\">
\t\t\t\t\t<a href=\"?c_face2\" title=\"Увеличить\">
\t\t\t\t\t\t<img src=\"/pic/pixel.gif\" width=\"164\" height=\"96\" alt=\"литер А, фасад S\" id=\"c_face2\">
\t\t\t\t\t</a><br>Фасад дома &ndash; южная сторона
\t\t\t\t</div>
\t\t\t</div>
\t\t</td> 
\t\t<td class=\"contentTabTd4\"></td>
\t</tr>
\t<tr> 
\t\t<td class=\"contentTabTd5\"></td> 
\t\t<td class=\"contentTabTd6\"></td>
\t</tr>
</table>
   
  ";
    }

    public function getTemplateName()
    {
        return "liter-c.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 4,  28 => 3,  11 => 1,);
    }
}
